import { createClient } from "@supabase/supabase-js";

export const createSupabaseServer = () =>
  createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, // ⚠️ server-only
    { auth: { persistSession: false, autoRefreshToken: false } }
  );
